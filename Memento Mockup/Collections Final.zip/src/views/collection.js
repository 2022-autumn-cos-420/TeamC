import React from 'react'

import { Helmet } from 'react-helmet'

import './collection.css'

const Collection = (props) => {
  return (
    <div className="collection-container">
      <Helmet>
        <title>exported project</title>
      </Helmet>
      <div className="collection-collection">
        <div className="collection-page-assets">
          <span className="collection-text">
            <span>Import</span>
          </span>
          <span className="collection-text02">
            <span>Study</span>
          </span>
          <span className="collection-text04">
            <span>
              <span>Collection</span>
              <br></br>
              <span></span>
            </span>
          </span>
          <span className="collection-text09">
            <span>Decks</span>
          </span>
          <span className="collection-text11">
            <span>memento</span>
          </span>
          <span className="collection-text13">
            <span className="collection-text14">
              <span></span>
              <br></br>
              <span></span>
            </span>
            <span className="collection-text18">
              <span>Collection</span>
              <br></br>
              <span></span>
              <br></br>
              <span></span>
            </span>
          </span>
        </div>
        <img
          alt="OutterMenu1031"
          src="/playground_assets/outtermenu1031-72ma-800h.png"
          className="collection-outter-menu"
        />
        <img
          alt="Vector1051"
          src="/playground_assets/vector1051-15uk.svg"
          className="collection-vector"
        />
        <span className="collection-text24">
          <span>
            <span>Front</span>
            <br></br>
            <span></span>
            <br></br>
            <span></span>
          </span>
        </span>
        <span className="collection-text31">
          <span>
            <span>
              COS 420
              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </span>
            <br></br>
            <span></span>
          </span>
        </span>
        <span className="collection-text36">
          <span>
            <span>PHI 100</span>
            <br></br>
            <span></span>
          </span>
        </span>
        <span className="collection-text41">
          <span>
            <span>NMD 324</span>
            <br></br>
            <span></span>
          </span>
        </span>
        <img
          alt="DeleteButton1031"
          src="/playground_assets/deletebutton1031-4pvm-200h.png"
          className="collection-delete-button"
        />
        <img
          alt="AssignButton1101"
          src="/playground_assets/assignbutton1101-4d3t-200h.png"
          className="collection-assign-button"
        />
        <img
          alt="EditButton2486"
          src="/playground_assets/editbutton2486-tqge-200h.png"
          className="collection-edit-button"
        />
        <img
          alt="AssignButton2481"
          src="/playground_assets/assignbutton2481-r0os-200h.png"
          className="collection-assign-button1"
        />
        <span className="collection-text46">
          <span>
            <span>
              Delete
              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </span>
            <br></br>
            <span></span>
          </span>
        </span>
        <span className="collection-text51">
          <span>
            <span>Assign</span>
            <br></br>
            <span></span>
          </span>
        </span>
        <span className="collection-text56">
          <span>
            <span>Edit</span>
            <br></br>
            <span></span>
          </span>
        </span>
        <span className="collection-text61">
          <span>
            <span>Export</span>
            <br></br>
            <span></span>
          </span>
        </span>
        <div className="collection-frameiconarrowthicktotop">
          <img
            alt="Vector2511"
            src="/playground_assets/vector2511-8n3j.svg"
            className="collection-vector01"
          />
          <img
            alt="Vector2511"
            src="/playground_assets/vector2511-x45.svg"
            className="collection-vector02"
          />
        </div>
        <div className="collection-frameicontrash">
          <img
            alt="Vector1111"
            src="/playground_assets/vector1111-ybwn.svg"
            className="collection-vector03"
          />
          <img
            alt="Vector1111"
            src="/playground_assets/vector1111-74zd.svg"
            className="collection-vector04"
          />
          <img
            alt="Vector1111"
            src="/playground_assets/vector1111-970a.svg"
            className="collection-vector05"
          />
          <img
            alt="Vector1111"
            src="/playground_assets/vector1111-1s2f.svg"
            className="collection-vector06"
          />
          <img
            alt="Vector1111"
            src="/playground_assets/vector1111-drhs.svg"
            className="collection-vector07"
          />
        </div>
        <div className="collection-frameiconfolderopen">
          <img
            alt="Vector1111"
            src="/playground_assets/vector1111-c7qs.svg"
            className="collection-vector08"
          />
        </div>
        <div className="collection-frameiconpencil">
          <img
            alt="Vector1352"
            src="/playground_assets/vector1352-0e1g.svg"
            className="collection-vector09"
          />
        </div>
        <div className="collection-slider">
          <img
            alt="Rectangle32511"
            src="/playground_assets/rectangle32511-w0gs-200w.png"
            className="collection-rectangle3"
          />
        </div>
      </div>
    </div>
  )
}

export default Collection
